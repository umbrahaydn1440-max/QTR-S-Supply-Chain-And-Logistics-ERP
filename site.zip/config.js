// Paste your Supabase values here (Project Settings > API). The anon key is meant to be public; NEVER paste the service_role key.
const SB_URL='https://YOUR-PROJECT-REF.supabase.co';
const SB_KEY='YOUR-ANON-PUBLIC-KEY';
